jQuery(function(){
    jQuery(window).scroll(function(){
        if(jQuery(this).scrollTop() > 200) {
            jQuery('#alog img')
                .css({'width':'121.3px','height':'112.6px'})
                .attr('nshimg/logo.png');
        }
        if(jQuery(this).scrollTop() < 400) {
            jQuery('#alog img')
                .css({'width':'140px',
                	'height':'130px',
					'-webkit-transition':'all 0.5s ease',
					'-moz-transition':'all 0.5s ease',
					'-ms-transition':'all 0.5s ease',
					'-o-transition':'all 0.5s ease',
					'transition':'all 0.5s ease'
                	})    
                .attr('nshimg/logo.png');
        }
    });
});


